# Go Security Audit Report (codeaudit)

## Scope, coverage, and method

- Scope: every Go file beneath `testdata/go-sec-code`.
- File coverage: **27/27 (100%)** — 24 production files and 3 test files, totalling 1,109 lines.
- Rule coverage: **8/8 (100%)** — web route/authentication, command execution, SQL/secrets, file/upload/archive, SSRF/outbound HTTP, template injection, resource/concurrency, and configuration/error handling.
- Method: `skills/codeaudit` evidence-driven review. Each reported issue has a verified source, propagation/control failure, reachable operation, and impact. Pattern matches without this evidence are not reported.

## Summary

| Severity | Count |
|---|---:|
| Critical | 2 |
| High | 7 |
| Medium | 5 |
| Low | 1 |

This is deliberately insecure sample code. It must not be run on a network-accessible host.

## Findings

### C-01 — Arbitrary host-file disclosure (CWE-200)

- Evidence: `pkg/router.go:47` maps `/files/` to `static.LocalFile("/etc", false)`.
- Reachability: global middleware does not enforce authentication (`pkg/filter/auth.go:5-8`).
- Impact: an unauthenticated request such as `/files/passwd` can read host files exposed from `/etc`.
- Remediation: remove the route. If static serving is needed, expose only an application-owned directory after authorization.

### C-02 — OS command injection (CWE-78)

- Evidence path: `pkg/handler/unsafe/exec.go:11` reads `host`; line 19 interpolates it into `cmd`; line 21 executes `/bin/bash -c cmd`. Route: `/unsafe/dig` in `pkg/router.go:23`.
- Impact: a caller can add shell metacharacters and execute commands as the service account.
- Remediation: do not invoke a shell; use `exec.Command("dig", validatedHost)` with a strict hostname policy.

### H-01 — SQL injection (CWE-89)

- Evidence path: `pkg/handler/unsafe/sqli.go:20` concatenates `c.Query("id")` into SQL; line 22 executes it. `pkg/conf/conf.go:41` additionally enables `multiStatements=true`.
- Impact: attacker-controlled SQL can disclose or alter database contents; multi-statements increases blast radius.
- Remediation: use placeholders (`WHERE id = ?`), parse the identifier as its expected type, and disable multi-statements.

### H-02 — SSRF with unrestricted response read (CWE-918)

- Evidence path: `pkg/handler/unsafe/ssrf.go:27` obtains caller-controlled `url`; it flows to `http.Get` at line 11, and its response is returned at line 28.
- Impact: requests can reach internal services or cloud metadata endpoints; absent timeout/body bounds also enable resource exhaustion.
- Remediation: use a URL/destination allowlist, validate resolved addresses and redirects, restrict schemes/ports, and set deadlines and response limits.

### H-03 — Arbitrary file read through traversal (CWE-22)

- Evidence path: `pkg/handler/unsafe/read_file.go:12-16` and `39-43` clean then join attacker-controlled paths before `os.Open`/`ReadFile`.
- Impact: `filepath.Clean` does not enforce base-directory containment; relative traversal can disclose readable files.
- Remediation: resolve against a fixed base, canonicalize both paths, and reject a result outside the base. Prefer resource identifiers over paths.

### H-04 — Tar Slip and archive resource exhaustion (CWE-22/CWE-409)

- Evidence path: `pkg/handler/unsafe/untar.go:53-68` writes `hdr.Name` under the destination without containment checks; `io.Copy` has no limits. Route: `/unsafe/decompress_tar`.
- Impact: crafted archive entries can escape the extraction directory or consume disk; link/special-file types are not rejected.
- Remediation: reject absolute/traversal/link/device entries; verify each resolved output path starts with the extraction root; impose entry-count and compressed/decompressed size limits.

### H-05 — Server-side template injection (CWE-1336)

- Evidence path: `pkg/handler/unsafe/ssti.go:25,52` inserts `q` into template source; lines 27,54 parse it. `BadTemplate2` executes using `*gin.Context`.
- Impact: template actions are attacker-controlled, enabling information disclosure and context method invocation.
- Remediation: parse constant templates only and pass `q` as data; never execute request-built templates with framework context.

### H-06 — Authentication bypass (CWE-306)

- Evidence: `pkg/filter/auth.go:5-8` sets a response header then unconditionally calls `Next()`; it performs no identity or authorization verification.
- Impact: every dangerous route is anonymously reachable.
- Remediation: verify identity and authorization before `Next()`; return 401/403 on failure and segregate development-only routes.

### H-07 — Hard-coded credentials (CWE-798)

- Evidence: database password is `123456` in `pkg/conf/conf.go:18`; `pkg/handler/user.go:31-34` accepts `admin/admin`.
- Impact: predictable credentials enable account/database compromise.
- Remediation: remove defaults, require secrets from an external secret store, hash user passwords, and use signed server-side authentication state.

### M-01 — Unbounded body and decompression processing (CWE-400)

- Evidence: `pkg/handler/research/unzipBody.go:19`, `read_body.go:29`, `unsafe/ssrf.go:17`, and `safe/proxy.go:99` use `ReadAll`/`io.Copy` on external streams without proved limits.
- Impact: oversized payloads or gzip bombs can exhaust memory, CPU, or disk.
- Remediation: enforce request and decompressed byte caps, limit entries/amplification, and configure server read/header/idle deadlines.

### M-02 — Request-triggered stack exhaustion (CWE-674)

- Evidence: `/research/fatal_error` maps to `DeepRecursive` (`pkg/router.go:39`); `pkg/handler/research/error.go:11-12` recursively calls itself without termination.
- Impact: a request can crash the process.
- Remediation: remove the endpoint and use bounded iterative logic.

### M-03 — Cross-request authorization race (CWE-362)

- Evidence: `pkg/handler/research/goroutine.go:9` declares global `goodUser`; lines 13,22,38,45 read/write it across requests and goroutines without synchronization.
- Impact: one request can influence another request's authorization result; a data race exists.
- Remediation: retain authorization state only in the request/session identity. A mutex alone does not fix the broken trust boundary.

### M-04 — Insecure deployment defaults (CWE-200)

- Evidence: `pkg/core/server.go:19` enables Gin debug mode; `pkg/conf/conf.go:10` binds to `0.0.0.0`.
- Impact: unintended exposure and verbose development diagnostics in production.
- Remediation: release mode and explicit production bind configuration should be the defaults.

### M-05 — Unsafe file/resource error handling (CWE-703)

- Evidence: `pkg/handler/unsafe/untar.go:64` discards `os.Create` error and checks stale `err`; extracted files are not closed. `pkg/handler/safe/file.go:15-21` does not close the file or check read/write errors.
- Impact: resource exhaustion and incorrect security-relevant error behavior.
- Remediation: handle every error, close each opened file, use restrictive permissions, and apply explicit size limits.

### L-01 — Missing outbound HTTP deadlines (CWE-400)

- Evidence: `http.Get` is used in `unsafe/ssrf.go:11` and `research/goroutine.go:18,42`; the proxy's client at `safe/proxy.go:58-99` has no overall timeout and dials without context/deadline.
- Impact: slow peers can retain connections and goroutines.
- Remediation: use context-aware dialing and a client with total, connect, and response-header timeouts.

## Execution record

| Activity | Status | Time |
|---|---|---:|
| Source discovery and focused static checks | Completed | < 1 s |
| `GOWORK=off go vet ./...` | Failed: `main.go:24` misuses an unbuffered `os.Signal` channel | 7.305 s |
| `GOWORK=off go test ./...` | Failed: `pkg/handler/research: TestInvalidUtf8` | 2.122 s |
| Measured automated checks | Completed; failures recorded | 9.427 s |

`GOWORK=off` was required because this target is a nested Go module excluded by the parent workspace. Audit coverage is review coverage, not a guarantee against unreviewed vulnerability classes.

## Remediation priority

1. Remove `/files/`, all `/unsafe/*`, and destructive `/research/*` routes from deployed builds.
2. Replace the no-op authentication mechanism and hard-coded credentials.
3. Remediate command, SQL, SSRF, path, archive, and template injection.
4. Add limits/timeouts and regression tests for every confirmed issue.
