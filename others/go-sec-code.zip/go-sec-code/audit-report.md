# Go Security Audit Report

## Scope and method

- Target: all Go source under `testdata/go-sec-code`.
- Reviewed: 27/27 Go files (24 production files, 3 test files), 1,109 lines; file coverage **100%**.
- Method: manual source and route/data-flow review plus focused checks for authentication, command execution, SQL, file handling, archive extraction, templates, SSRF, resource exhaustion, error handling, and insecure configuration.
- Review date: 2026-07-30.

## Result summary

| Severity | Count |
|---|---:|
| Critical | 2 |
| High | 7 |
| Medium | 5 |
| Low | 1 |

The application intentionally contains vulnerable examples, but it must not be deployed or exposed outside an isolated training environment. In particular, `/files/` exposes the host `/etc` directory without effective authentication.

## Findings

### C-01 Arbitrary host file disclosure

- Location: `pkg/router.go:47`
- Evidence: `static.LocalFile("/etc", false)` publishes the entire `/etc` tree at `/files/`.
- Impact: unauthenticated callers can read sensitive host configuration and credential material, such as `/files/passwd`, application configuration, or mounted-secret files.
- Fix: remove this route. If static files are required, serve a dedicated application-owned directory with an allowlist and authorization.

### C-02 OS command injection

- Location: `pkg/handler/unsafe/exec.go:19-21`; route `/unsafe/dig`
- Evidence: request parameter `host` is interpolated into a shell command and run through `/bin/bash -c`.
- Impact: remote command execution with the service account's permissions.
- Fix: never invoke a shell for this operation; pass a validated hostname as a separate argument to `exec.Command` and enforce an allowlist.

### H-01 SQL injection, amplified by multi-statements

- Location: `pkg/handler/unsafe/sqli.go:20-22`, `pkg/conf/conf.go:41`
- Evidence: query text concatenates `c.Query("id")`; MySQL DSN enables `multiStatements=true`.
- Impact: data disclosure, modification, or destructive SQL. Multi-statement support broadens the impact.
- Fix: use a parameterized query (`WHERE id = ?`), validate the expected integer type, and remove `multiStatements=true`.

### H-02 Server-side request forgery

- Location: `pkg/handler/unsafe/ssrf.go:11,27`; route `/unsafe/ssrf`
- Evidence: caller-controlled URL is sent directly to `http.Get`.
- Impact: access to loopback, cloud metadata, and internal services; response body is relayed to the caller.
- Fix: use an allowlist of destinations, resolve and validate every address including redirects, use a bounded client, and restrict schemes/ports.

### H-03 Path traversal / arbitrary file read

- Location: `pkg/handler/unsafe/read_file.go:12-16,39-43`; routes `/unsafe/read_file1` and `/unsafe/read_file2`
- Evidence: `filepath.Clean` and `filepath.Join("./", path)` do not confine paths; `../../` escapes the intended directory.
- Impact: unauthenticated disclosure of readable server files.
- Fix: use a fixed base directory, derive a relative path, then reject paths outside the base after canonicalization; avoid returning raw files by user-supplied path.

### H-04 Archive path traversal and unbounded extraction

- Location: `pkg/handler/unsafe/untar.go:53-68`; route `/unsafe/decompress_tar`
- Evidence: archive entry `hdr.Name` is appended to the destination without containment validation. Extraction has no size, entry-count, or type restrictions.
- Impact: tar-slip arbitrary file overwrite, disk exhaustion, and unsafe special-file/link extraction.
- Fix: reject absolute, `..`, symlink, hardlink, device, and unsupported entry names; verify each resolved output path remains in the extraction root; enforce compressed/uncompressed size and entry limits.

### H-05 Server-side template injection

- Location: `pkg/handler/unsafe/ssti.go:25-27,52-54`; routes `/unsafe/ssti1` and `/unsafe/ssti2`
- Evidence: user input is inserted into template source before `Parse`; the second handler executes with `*gin.Context`.
- Impact: template expression injection, sensitive-data disclosure, and potentially context method invocation such as file upload.
- Fix: parse a constant template once and pass `q` only as data; never parse request-controlled template source or execute with framework context.

### H-06 Authentication middleware does not authenticate

- Location: `pkg/filter/auth.go:5-8`
- Evidence: middleware unconditionally sets response header `auth: success` and calls `Next()`.
- Impact: all routes, including file exposure and dangerous handlers, are publicly reachable.
- Fix: implement authentication and authorization before `Next()`, return 401/403 on failure, and deny sensitive routes by default.

### H-07 Hard-coded default credentials

- Location: `pkg/conf/conf.go:17-18`, `pkg/handler/user.go:31-34`
- Evidence: database password is `123456`; login accepts fixed `admin/admin` credentials and grants a header-based identity indicator.
- Impact: trivial account/database compromise and unauthenticated privilege signalling.
- Fix: remove defaults from source, load secrets from a secret manager or required environment variables, store password hashes, and issue signed server-side sessions/tokens.

### M-01 Unbounded request/decompression/body reads cause denial of service

- Location: `pkg/handler/research/unzipBody.go:19`, `pkg/handler/research/read_body.go:29`, `pkg/handler/unsafe/ssrf.go:17`, `pkg/handler/safe/proxy.go:99`
- Evidence: `ReadAll`/`io.Copy` consume attacker-controlled streams without a size limit; gzip handler does not cap decompressed bytes.
- Impact: memory, disk, goroutine, or CPU exhaustion (including gzip bombs).
- Fix: configure `http.Server` read/header/idle timeouts and `MaxHeaderBytes`; wrap bodies with `http.MaxBytesReader`/`io.LimitReader`; reject over-limit compressed and decompressed payloads.

### M-02 Deliberate infinite recursion endpoint

- Location: `pkg/handler/research/error.go:11-12`; route `/research/fatal_error`
- Evidence: `DeepRecursive` calls itself without a termination condition.
- Impact: a single request can terminate the process through stack exhaustion.
- Fix: remove the endpoint; replace recursion with bounded logic where required.

### M-03 Race condition and global authorization state

- Location: `pkg/handler/research/goroutine.go:9-45`; route `/research/goodman`
- Evidence: global `goodUser` is read/written by concurrent requests and a spawned goroutine without synchronization; authorization result is shared across clients.
- Impact: data race and cross-request privilege confusion.
- Fix: keep identity state request-local; use a real authorization mechanism. Do not repair this with a mutex alone, as the security model remains invalid.

### M-04 Insecure deployment defaults

- Location: `pkg/core/server.go:19`, `pkg/conf/conf.go:10`
- Evidence: Gin debug mode and bind address `0.0.0.0` are defaults.
- Impact: verbose debug output and unintended network exposure in production.
- Fix: default to release mode and loopback/private deployment configuration; require explicit production configuration.

### M-05 Unsafe file handling and ignored errors in extraction

- Location: `pkg/handler/unsafe/untar.go:15,64-68`; `pkg/handler/safe/file.go:15-21`
- Evidence: `os.Mkdir` error is ignored; `os.Create` error is assigned to `_` then stale `err` is checked; created files are not closed. The purported safe reader neither closes the file nor checks read/write errors.
- Impact: resource exhaustion, incorrect failure handling, and unreliable security controls.
- Fix: check and return every error, use restrictive permissions, close files promptly, and make resource limits explicit.

### L-01 Missing HTTP client timeouts

- Location: `pkg/handler/unsafe/ssrf.go:11`, `pkg/handler/research/goroutine.go:18,42`, `pkg/handler/safe/proxy.go:58-99`
- Evidence: outbound calls use `http.Get` or a client without an overall timeout; the custom proxy also calls `net.Dial` without context/deadline.
- Impact: slow peers can retain service goroutines and connections.
- Fix: use context-aware dialing and a bounded `http.Client` timeout; propagate request cancellation.

## Rule coverage

| Rule family | Files reviewed | Result |
|---|---:|---|
| Route exposure and authentication | 27/27 | Findings C-01, H-06, H-07 |
| Command execution | 27/27 | C-02 |
| SQL and secrets | 27/27 | H-01, H-07 |
| Files, uploads, archives | 27/27 | C-01, H-03, H-04, M-05 |
| SSRF and outbound HTTP | 27/27 | H-02, L-01 |
| Templates/output injection | 27/27 | H-05 |
| Resource exhaustion/concurrency | 27/27 | M-01, M-02, M-03 |
| Error handling and configuration | 27/27 | M-04, M-05 |

Rule coverage is **8/8 (100%)** for the planned audit rule families. This is review coverage, not a claim that every possible vulnerability class is absent.

## Measured execution time and checks

| Activity | Result | Time |
|---|---|---:|
| File discovery and static pattern scan | Completed | < 1 s |
| `GOWORK=off go vet ./...` | Failed: `main.go:24` passes an unbuffered signal channel to `signal.Notify` | 7.305 s |
| `GOWORK=off go test ./...` | Failed: `pkg/handler/research: TestInvalidUtf8`; output also shows test-side excessive logging | 2.122 s |
| Measured automated checks total | Completed with failures recorded | 9.427 s |

`go vet` was run with `GOWORK=off` because the parent workspace excludes this nested module. The test failure is a quality issue and does not invalidate the source-review findings.

## Remediation order

1. Remove `/files/`, all `/unsafe/*`, and the destructive `/research/*` routes from any deployed build.
2. Replace the no-op authentication mechanism and remove hard-coded credentials.
3. Eliminate command, SQL, SSRF, path, archive, and template injection paths.
4. Add request/response/resource limits and HTTP timeouts; then add regression tests for every finding.
